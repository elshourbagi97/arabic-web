import React, { useState } from 'react';
import { PrimaryButton } from './PrimaryButton';

interface RegistrationPageProps {
  onRegister: (email: string, password: string, role: 'admin' | 'user') => void;
  onSwitchToLogin: () => void;
}

export function RegistrationPage({ onRegister, onSwitchToLogin }: RegistrationPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<'user' | 'admin'>('user');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password || !confirmPassword) {
      setError('الرجاء ملء جميع الحقول');
      return;
    }

    if (!email.includes('@')) {
      setError('الرجاء إدخال بريد إلكتروني صحيح');
      return;
    }

    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    if (password !== confirmPassword) {
      setError('كلمة المرور وتأكيد كلمة المرور غير متطابقتين');
      return;
    }

    onRegister(email, password, role);
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4"
      dir="rtl"
      style={{ fontFamily: 'Cairo, sans-serif' }}
    >
      <div className="w-full max-w-md">
        {/* Logo/Header Section */}
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-[var(--primary-blue)] rounded-full mb-4 shadow-lg">
            <svg 
              className="w-12 h-12 text-white" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" 
              />
            </svg>
          </div>
          <h1 
            className="mb-2"
            style={{ 
              fontSize: '28px',
              fontWeight: 700,
              color: 'var(--text-dark)'
            }}
          >
            إنشاء حساب جديد
          </h1>
          <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--text-medium)' }}>
            انضم إلى نظام إدارة الفحوصات
          </p>
        </div>

        {/* Registration Form */}
        <div className="bg-white rounded-lg shadow-xl p-8">
          <form onSubmit={handleSubmit}>
            {/* Error Message */}
            {error && (
              <div 
                className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700"
                style={{ fontSize: 'var(--font-size-sm)' }}
              >
                {error}
              </div>
            )}

            {/* Email Input */}
            <div className="mb-5">
              <label 
                htmlFor="email"
                className="block mb-2"
                style={{ 
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: 600,
                  color: 'var(--text-dark)'
                }}
              >
                البريد الإلكتروني
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-gray)] rounded-lg 
                  focus:outline-none focus:ring-2 focus:ring-[var(--primary-blue)] focus:border-transparent
                  transition-all"
                placeholder="example@domain.com"
                style={{ fontSize: 'var(--font-size-md)' }}
                dir="ltr"
              />
            </div>

            {/* Password Input */}
            <div className="mb-5">
              <label 
                htmlFor="password"
                className="block mb-2"
                style={{ 
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: 600,
                  color: 'var(--text-dark)'
                }}
              >
                كلمة المرور
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-gray)] rounded-lg 
                  focus:outline-none focus:ring-2 focus:ring-[var(--primary-blue)] focus:border-transparent
                  transition-all"
                placeholder="6 أحرف على الأقل"
                style={{ fontSize: 'var(--font-size-md)' }}
              />
            </div>

            {/* Confirm Password Input */}
            <div className="mb-5">
              <label 
                htmlFor="confirmPassword"
                className="block mb-2"
                style={{ 
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: 600,
                  color: 'var(--text-dark)'
                }}
              >
                تأكيد كلمة المرور
              </label>
              <input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-gray)] rounded-lg 
                  focus:outline-none focus:ring-2 focus:ring-[var(--primary-blue)] focus:border-transparent
                  transition-all"
                placeholder="أعد إدخال كلمة المرور"
                style={{ fontSize: 'var(--font-size-md)' }}
              />
            </div>

            {/* Role Selection */}
            <div className="mb-6">
              <label 
                className="block mb-2"
                style={{ 
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: 600,
                  color: 'var(--text-dark)'
                }}
              >
                نوع الحساب
              </label>
              <div className="flex gap-4">
                <label className="flex items-center flex-1 cursor-pointer p-3 border-2 rounded-lg transition-all"
                  style={{
                    borderColor: role === 'user' ? 'var(--primary-blue)' : 'var(--border-gray)',
                    backgroundColor: role === 'user' ? 'rgba(34, 113, 177, 0.05)' : 'white'
                  }}
                >
                  <input 
                    type="radio" 
                    name="role"
                    value="user"
                    checked={role === 'user'}
                    onChange={(e) => setRole(e.target.value as 'user')}
                    className="ml-2"
                  />
                  <div>
                    <div style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                      مستخدم
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--text-medium)' }}>
                      إدارة الجداول الخاصة
                    </div>
                  </div>
                </label>
                
                <label className="flex items-center flex-1 cursor-pointer p-3 border-2 rounded-lg transition-all"
                  style={{
                    borderColor: role === 'admin' ? 'var(--primary-blue)' : 'var(--border-gray)',
                    backgroundColor: role === 'admin' ? 'rgba(34, 113, 177, 0.05)' : 'white'
                  }}
                >
                  <input 
                    type="radio" 
                    name="role"
                    value="admin"
                    checked={role === 'admin'}
                    onChange={(e) => setRole(e.target.value as 'admin')}
                    className="ml-2"
                  />
                  <div>
                    <div style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                      مدير
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--text-medium)' }}>
                      صلاحيات كاملة
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* Terms */}
            <div className="mb-6">
              <label className="flex items-start cursor-pointer">
                <input 
                  type="checkbox" 
                  className="mt-1 ml-2 w-4 h-4 text-[var(--primary-blue)] 
                    border-gray-300 rounded focus:ring-[var(--primary-blue)]"
                  required
                />
                <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--text-medium)' }}>
                  أوافق على{' '}
                  <a href="#" className="hover:underline" style={{ color: 'var(--primary-blue)' }}>
                    الشروط والأحكام
                  </a>
                  {' '}و{' '}
                  <a href="#" className="hover:underline" style={{ color: 'var(--primary-blue)' }}>
                    سياس�� الخصوصية
                  </a>
                </span>
              </label>
            </div>

            {/* Register Button */}
            <div className="mb-4">
              <PrimaryButton type="submit" className="w-full">
                إنشاء الحساب
              </PrimaryButton>
            </div>
          </form>
        </div>

        {/* Login Link */}
        <div className="mt-6 text-center">
          <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--text-medium)' }}>
            لديك حساب بالفعل؟{' '}
            <button
              onClick={onSwitchToLogin}
              className="hover:underline"
              style={{ 
                color: 'var(--primary-blue)',
                fontWeight: 600
              }}
            >
              تسجيل الدخول
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
