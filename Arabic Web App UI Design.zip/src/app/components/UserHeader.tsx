import React from 'react';

interface User {
  email: string;
  role: 'admin' | 'user';
}

interface UserHeaderProps {
  user: User;
  onLogout?: () => void;
}

export function UserHeader({ user, onLogout }: UserHeaderProps) {
  return (
    <div className="bg-white border-b border-[var(--light-gray)] px-8 py-4 shadow-sm">
      <div className="max-w-[1600px] mx-auto flex justify-between items-center" dir="rtl">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[var(--primary-blue)] text-white rounded-full flex items-center justify-center">
              <span style={{ fontSize: 'var(--font-size-md)', fontWeight: 600 }}>
                {user.email.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <p style={{ fontSize: 'var(--font-size-md)', fontWeight: 500, color: 'var(--text-dark)' }}>
                {user.email}
              </p>
              {user.role === 'admin' && (
                <span className="inline-block px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded text-xs" style={{ fontSize: '11px' }}>
                  مدير النظام
                </span>
              )}
            </div>
          </div>
        </div>

        {onLogout && (
          <button
            onClick={onLogout}
            className="px-4 py-2 text-[var(--text-medium)] hover:text-[var(--primary-blue)] transition-colors"
            style={{ fontSize: 'var(--font-size-sm)' }}
          >
            تسجيل الخروج
          </button>
        )}
      </div>
    </div>
  );
}