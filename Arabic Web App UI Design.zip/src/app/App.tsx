import React, { useState } from "react";
import { TopSelectionButton } from "./components/TopSelectionButton";
import { TableContainer } from "./components/TableContainer";
import { NotesTextarea } from "./components/NotesTextarea";
import { InspectionTabs } from "./components/InspectionTabs";
import { PrimaryButton } from "./components/PrimaryButton";
import { SecondaryButton } from "./components/SecondaryButton";
import { AnimatedAddButton } from "./components/AnimatedAddButton";
import { UserHeader } from "./components/UserHeader";
import { AdminPanel } from "./components/AdminPanel";
import { ImageUploadPage } from "./components/ImageUploadPage";
import { LoginPage } from "./components/LoginPage";
import { RegistrationPage } from "./components/RegistrationPage";

interface TableData {
  id: string;
  label: string;
  data: string[][];
  columnHeaders: string[];
  notes: string;
}

interface User {
  email: string;
  role: "admin" | "user";
}

interface UserTableData {
  [userEmail: string]: {
    tables: TableData[];
    activeTableId: string;
  };
}

type SectionType =
  | "building1"
  | "building2"
  | "school"
  | "notes"
  | "images"
  | "admin";

// Store registered users (in real app, this would be in a database)
const registeredUsers: {
  [email: string]: { password: string; role: "admin" | "user" };
} = {
  "user@wordpress.local": { password: "password", role: "user" },
  "admin@wordpress.local": { password: "admin", role: "admin" },
};

function App() {
  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authView, setAuthView] = useState<"login" | "register">("login");
  const [activeSection, setActiveSection] =
    useState<SectionType | null>(null);

  // Store tables per user
  const [userTablesData, setUserTablesData] =
    useState<UserTableData>({
      "user@wordpress.local": {
        tables: [
          {
            id: "table-1",
            label: "جدول 1",
            data: Array(12)
              .fill(null)
              .map(() => Array(20).fill("")),
            columnHeaders: Array(20).fill(""),
            notes: "",
          },
        ],
        activeTableId: "table-1",
      },
      "admin@wordpress.local": {
        tables: [
          {
            id: "table-1",
            label: "جدول 1",
            data: Array(12)
              .fill(null)
              .map(() => Array(20).fill("")),
            columnHeaders: Array(20).fill(""),
            notes: "",
          },
        ],
        activeTableId: "table-1",
      },
    });

  const handleSectionSelect = (section: SectionType) => {
    setActiveSection(section);
  };

  const getCurrentUserData = () => {
    if (!currentUser) return null;
    return (
      userTablesData[currentUser.email] || {
        tables: [],
        activeTableId: "",
      }
    );
  };

  const updateCurrentUserData = (
    updater: (
      data: (typeof userTablesData)[string],
    ) => (typeof userTablesData)[string],
  ) => {
    if (!currentUser) return;
    setUserTablesData({
      ...userTablesData,
      [currentUser.email]: updater(
        userTablesData[currentUser.email],
      ),
    });
  };

  const handleAddTable = () => {
    const userData = getCurrentUserData();
    if (!userData) return;

    if (userData.tables.length < 3) {
      const newTable: TableData = {
        id: `table-${userData.tables.length + 1}`,
        label: `جدول ${userData.tables.length + 1}`,
        data: Array(12)
          .fill(null)
          .map(() => Array(20).fill("")),
        columnHeaders: Array(20).fill(""),
        notes: "",
      };
      updateCurrentUserData((data) => ({
        tables: [...data.tables, newTable],
        activeTableId: newTable.id,
      }));
    }
  };

  const handleRemoveTable = (tableId: string) => {
    const userData = getCurrentUserData();
    if (!userData || userData.tables.length <= 1) return;

    const newTables = userData.tables.filter(
      (t) => t.id !== tableId,
    );
    updateCurrentUserData((data) => ({
      tables: newTables,
      activeTableId:
        data.activeTableId === tableId
          ? newTables[0].id
          : data.activeTableId,
    }));
  };

  const handleDataChange = (
    rowIndex: number,
    colIndex: number,
    value: string,
  ) => {
    updateCurrentUserData((data) => ({
      ...data,
      tables: data.tables.map((table) => {
        if (table.id === data.activeTableId) {
          const newData = [...table.data];
          if (!newData[rowIndex]) {
            newData[rowIndex] = Array(20).fill("");
          }
          newData[rowIndex][colIndex] = value;
          return { ...table, data: newData };
        }
        return table;
      }),
    }));
  };

  const handleNotesChange = (value: string) => {
    updateCurrentUserData((data) => ({
      ...data,
      tables: data.tables.map((table) =>
        table.id === data.activeTableId
          ? { ...table, notes: value }
          : table,
      ),
    }));
  };

  const handleColumnHeaderChange = (colIndex: number, value: string) => {
    updateCurrentUserData((data) => ({
      ...data,
      tables: data.tables.map((table) => {
        if (table.id === data.activeTableId) {
          const newHeaders = [...table.columnHeaders];
          newHeaders[colIndex] = value;
          return { ...table, columnHeaders: newHeaders };
        }
        return table;
      }),
    }));
  };

  const handleExportPDF = () => {
    alert(
      "تصدير إلى PDF - هذه الميزة ستتطلب مكتبة PDF في التطبيق النهائي",
    );
  };

  const handleAutoSave = () => {
    console.log("حفظ تلقائي...", {
      userTablesData,
      currentUser,
    });
    alert("تم الحفظ التلقائي بنجاح");
  };

  const setActiveTableId = (tableId: string) => {
    updateCurrentUserData((data) => ({
      ...data,
      activeTableId: tableId,
    }));
  };

  // Get all users for admin panel
  const getAllUsersData = () => {
    return Object.entries(userTablesData).map(
      ([email, data]) => ({
        email,
        tableCount: data.tables.length,
        lastActive: "اليوم", // Mock data
      }),
    );
  };

  // Authentication handlers
  const handleLogin = (email: string, password: string) => {
    const user = registeredUsers[email];
    
    if (user && user.password === password) {
      setCurrentUser({ email, role: user.role });
      
      // Initialize user data if not exists
      if (!userTablesData[email]) {
        setUserTablesData({
          ...userTablesData,
          [email]: {
            tables: [
              {
                id: "table-1",
                label: "جدول 1",
                data: Array(12)
                  .fill(null)
                  .map(() => Array(20).fill("")),
                columnHeaders: Array(20).fill(""),
                notes: "",
              },
            ],
            activeTableId: "table-1",
          },
        });
      }
    } else {
      alert("البريد الإلكتروني أو كلمة المرور غير صحيحة");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveSection(null);
  };

  const handleRegister = (email: string, password: string, role: 'admin' | 'user') => {
    if (registeredUsers[email]) {
      alert("هذا البريد الإلكتروني مسجل بالفعل");
      return;
    }

    // Register the user
    registeredUsers[email] = { password, role };
    
    // Create initial user data
    const newUserData = {
      tables: [
        {
          id: "table-1",
          label: "جدول 1",
          data: Array(12)
            .fill(null)
            .map(() => Array(20).fill("")),
          columnHeaders: Array(20).fill(""),
          notes: "",
        },
      ],
      activeTableId: "table-1",
    };

    setUserTablesData({
      ...userTablesData,
      [email]: newUserData,
    });

    // Auto login after registration
    setCurrentUser({ email, role });
    alert("تم إنشاء الحساب بنجاح!");
  };

  // Show login/registration pages if not logged in
  if (!currentUser) {
    if (authView === 'login') {
      return (
        <LoginPage 
          onLogin={handleLogin}
          onSwitchToRegister={() => setAuthView('register')}
        />
      );
    } else {
      return (
        <RegistrationPage 
          onRegister={handleRegister}
          onSwitchToLogin={() => setAuthView('login')}
        />
      );
    }
  }

  const userData = getCurrentUserData();
  if (!userData) return null;

  const activeTable = userData.tables.find(
    (t) => t.id === userData.activeTableId,
  );

  // Get table title based on active section
  const getTableTitle = () => {
    switch (activeSection) {
      case "building1":
        return "عمارة 1";
      case "building2":
        return "عمارة 2";
      case "school":
        return "مدرسة";
      default:
        return "";
    }
  };

  return (
    <div
      className="min-h-screen bg-gray-50"
      style={{ fontFamily: "Cairo, sans-serif" }}
    >
      {/* User Header */}
      <UserHeader user={currentUser} onLogout={handleLogout} />

      <div className="max-w-[1600px] mx-auto p-8" dir="rtl">
        {/* Header */}
        <div className="mb-8">
          <h1
            className="mb-2"
            style={{
              fontSize: "var(--font-size-lg)",
              fontWeight: 600,
              color: "var(--text-dark)",
            }}
          >
            إدارة جداول الفحص الديناميكية
          </h1>
          <p
            style={{
              fontSize: "var(--font-size-sm)",
              color: "var(--text-medium)",
            }}
          >
            نظام إدارة الفحوصات والتقارير الهندسية
          </p>
        </div>

        {/* Top Selection Section */}
        <div className="mb-8 bg-white p-6 rounded-lg shadow-sm">
          <h2
            className="mb-4"
            style={{
              fontSize: "var(--font-size-md)",
              fontWeight: 600,
              color: "var(--text-dark)",
            }}
          >
            اختر القسم
          </h2>
          <div className="flex gap-4 flex-wrap">
            <TopSelectionButton
              isActive={activeSection === "building1"}
              onClick={() => handleSectionSelect("building1")}
            >
              عمارة 1
            </TopSelectionButton>
            <TopSelectionButton
              isActive={activeSection === "building2"}
              onClick={() => handleSectionSelect("building2")}
            >
              عمارة 2
            </TopSelectionButton>
            <TopSelectionButton
              isActive={activeSection === "school"}
              onClick={() => handleSectionSelect("school")}
            >
              مدرسة
            </TopSelectionButton>
            <TopSelectionButton
              isActive={activeSection === "notes"}
              onClick={() => handleSectionSelect("notes")}
            >
              ملاحظات
            </TopSelectionButton>
            <TopSelectionButton
              isActive={activeSection === "images"}
              onClick={() => handleSectionSelect("images")}
            >
              📷 الصور
            </TopSelectionButton>
            {currentUser?.role === "admin" && (
              <TopSelectionButton
                isActive={activeSection === "admin"}
                onClick={() => handleSectionSelect("admin")}
              >
                ⚙️ الإدارة
              </TopSelectionButton>
            )}
          </div>
        </div>

        {/* Admin Panel */}
        {activeSection === "admin" &&
          currentUser?.role === "admin" && (
            <AdminPanel users={getAllUsersData()} />
          )}

        {/* Image Upload Page */}
        {activeSection === "images" && (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <ImageUploadPage />
          </div>
        )}

        {/* Main Content - Only show when section is selected */}
        {activeSection &&
          activeSection !== "notes" &&
          activeSection !== "images" &&
          activeSection !== "admin" && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              {/* Tabs for multiple tables */}
              <InspectionTabs
                tabs={userData.tables}
                activeTab={userData.activeTableId}
                onTabChange={setActiveTableId}
                onRemoveTab={handleRemoveTable}
                canRemove={userData.tables.length > 1}
              />

              {/* Table Title - Centered and Prominent */}
              <div className="text-center mb-6">
                <h2
                  style={{
                    fontSize: "20px",
                    fontWeight: 600,
                    color: "var(--text-dark)",
                  }}
                >
                  {getTableTitle()}
                </h2>
              </div>

              {/* Table Section */}
              <div className="mb-6">
                {activeTable && (
                  <TableContainer
                    rows={12}
                    columns={20}
                    data={activeTable.data}
                    columnHeaders={activeTable.columnHeaders}
                    onDataChange={handleDataChange}
                    onColumnHeaderChange={handleColumnHeaderChange}
                  />
                )}
              </div>

              {/* Add Table Button */}
              {userData.tables.length < 3 && (
                <div className="mb-6">
                  <AnimatedAddButton onClick={handleAddTable}>
                    إضافة جدول
                  </AnimatedAddButton>
                </div>
              )}

              {/* Notes Section */}
              <div className="mb-6">
                {activeTable && (
                  <NotesTextarea
                    value={activeTable.notes}
                    onChange={handleNotesChange}
                  />
                )}
              </div>

              {/* Actions Section */}
              <div className="flex gap-4 justify-start border-t border-[var(--light-gray)] pt-6">
                <PrimaryButton onClick={handleExportPDF}>
                  تصدير إلى PDF
                </PrimaryButton>
                <SecondaryButton onClick={handleAutoSave}>
                  حفظ تلقائي
                </SecondaryButton>
              </div>
            </div>
          )}

        {/* Notes-only Section */}
        {activeSection === "notes" && (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3
              className="mb-4"
              style={{
                fontSize: "var(--font-size-md)",
                fontWeight: 600,
                color: "var(--text-dark)",
              }}
            >
              ملاحظات عامة
            </h3>
            <NotesTextarea
              value={activeTable?.notes || ""}
              onChange={handleNotesChange}
              placeholder="أدخل الملاحظات العامة هنا..."
            />
            <div className="mt-6">
              <SecondaryButton onClick={handleAutoSave}>
                حفظ الملاحظات
              </SecondaryButton>
            </div>
          </div>
        )}

        {/* Initial State Message */}
        {!activeSection && (
          <div className="bg-white p-12 rounded-lg shadow-sm text-center">
            <p
              style={{
                fontSize: "var(--font-size-lg)",
                color: "var(--text-medium)",
              }}
            >
              الرجاء اختيار قسم من الأعلى للبدء
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;